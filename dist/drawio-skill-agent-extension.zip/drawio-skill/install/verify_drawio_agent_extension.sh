#!/usr/bin/env bash
set -Eeuo pipefail

EXTENSION_NAME="publish-drawio-skill"
EXPECTED_VERSION="${DRAWIO_EXTENSION_VERSION:-1.25.0-corporate.1}"
GIGACODE_HOME="${GIGACODE_HOME:-$HOME/.gigacode}"
GIGACODE_BIN="${GIGACODE_BIN:-$GIGACODE_HOME/bin/gigacode}"
GIGACODE_SKILLS_DIR="${GIGACODE_SKILLS_DIR:-$GIGACODE_HOME/skills}"
GIGACODE_EXTENSIONS_DIR="${GIGACODE_EXTENSIONS_DIR:-$GIGACODE_HOME/extensions}"
GIGACODE_EXTENSION_SOURCES_DIR="${GIGACODE_EXTENSION_SOURCES_DIR:-$GIGACODE_HOME/extension-sources}"
PYTHON_BIN="${PYTHON_BIN:-python3}"
skip_self_check=0
source_path=""

usage() {
  cat <<'EOF'
Usage: verify_drawio_agent_extension.sh [--source PATH] [--skip-self-check]

Checks the installed manifest, four agent definitions, native GigaCode
registration, legacy-skill conflicts, and the extension self-check.
EOF
}

log() { printf '[drawio-extension:verify] %s\n' "$*"; }
die() { printf '[drawio-extension:verify] ERROR: %s\n' "$*" >&2; exit 1; }

extensions_supports_validate() {
  local help_text
  help_text="$("$GIGACODE_BIN" extensions --help 2>&1 || true)"

  if grep -Eq '^[[:space:]]*gigacode[[:space:]]+extensions[[:space:]]+validate([[:space:]<]|$)' <<<"$help_text"; then
    return 0
  fi

  if grep -Eq '^[[:space:]]*(Commands:|gigacode[[:space:]]+extensions[[:space:]]+<command>)' <<<"$help_text"; then
    return 1
  fi

  "$GIGACODE_BIN" extensions validate --help >/dev/null 2>&1
}

verify_role_runtime_capabilities() {
  local help_text flag missing=()
  help_text="$($GIGACODE_BIN --help 2>&1 || true)"
  for flag in --model --prompt --output-format --approval-mode --extensions --system-prompt --max-session-turns --core-tools --allowed-mcp-server-names --exclude-tools; do
    grep -Fq -- "$flag" <<<"$help_text" || missing+=("$flag")
  done
  ((${#missing[@]} == 0)) || die "GigaCode CLI lacks required isolated-role flags: ${missing[*]}"
  log "Verified headless role-isolation capabilities"
}

while (($#)); do
  case "$1" in
    --source) [[ $# -ge 2 ]] || die "--source requires PATH"; source_path="$2"; shift 2 ;;
    --skip-self-check) skip_self_check=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) die "Unknown option: $1" ;;
  esac
done

[[ -x "$GIGACODE_BIN" ]] || die "GigaCode CLI not executable: $GIGACODE_BIN"
command -v "$PYTHON_BIN" >/dev/null 2>&1 || die "Python not found: $PYTHON_BIN"
verify_role_runtime_capabilities

current="$GIGACODE_EXTENSION_SOURCES_DIR/$EXTENSION_NAME/current"
installed="$GIGACODE_EXTENSIONS_DIR/$EXTENSION_NAME"
[[ -f "$installed/gemini-extension.json" ]] || die "Active extension is missing: $installed/gemini-extension.json"
if [[ -n "$source_path" ]]; then
  source_path="$(cd "$source_path" 2>/dev/null && pwd)" || die "Source path not found: $source_path"
elif [[ -f "$current/gemini-extension.json" ]]; then
  source_path="$current"
else
  source_path=""
fi

"$PYTHON_BIN" - "$installed" "$source_path" "$current" "$EXPECTED_VERSION" <<'PY'
import hashlib
import json
import os
import re
import sys
from pathlib import Path, PurePosixPath

active = Path(sys.argv[1]).resolve()
source = Path(sys.argv[2]).resolve() if sys.argv[2] else None
current = Path(sys.argv[3])
expected_version = sys.argv[4]
expected_models = {
    "supervisor": "GigaChat-3-Ultra",
    "reviewer": "vllm/DeepSeek-V4-Flash-262k",
    "repair": "vllm/MiniMax-M3-113k",
    "semantic_analyst": "vllm/Qwen3.6-35B-262k",
}
agent_files = {
    "supervisor": "diagram-supervisor.md",
    "reviewer": "diagram-reviewer.md",
    "repair": "diagram-repair.md",
    "semantic_analyst": "diagram-semantic-analyst.md",
}


def fail(message):
    raise SystemExit(message)


def load_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        fail(f"Cannot read JSON {path}: {exc}")


def frontmatter(path):
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        fail(f"Missing agent definition {path}: {exc}")
    match = re.match(r"\A---\n(.*?)\n---\n", text, re.DOTALL)
    if not match:
        fail(f"Malformed YAML frontmatter: {path}")
    values = {}
    for line in match.group(1).splitlines():
        item = re.match(r"^([A-Za-z][A-Za-z0-9]*):\s*(.*?)\s*$", line)
        if item:
            values[item.group(1)] = item.group(2)
    return values


COMMAND_FILES = (
    "commands/drawio/create.md",
    "commands/drawio/improve.md",
    "commands/drawio/review.md",
    "commands/drawio/resume.md",
    "commands/drawio/trace.md",
)

LAYOUT_RELEASE_FILES = (
    "scripts/diagram_intake.py",
    "scripts/layout_contracts.py",
    "scripts/layout_geometry.py",
    "scripts/layout_model.py",
    "scripts/layout_builtin.py",
    "scripts/layout_backend.py",
    "scripts/layout_renderer.py",
    "scripts/sequence_adapter.py",
    "scripts/elk_runner.mjs",
    "vendor/elkjs/elk.bundled.js",
    "vendor/elkjs/LICENSE",
    "vendor/elkjs/NOTICE.json",
    "data/diagram-intake.v1.schema.json",
    "data/diagram-intake-analysis.v1.schema.json",
    "data/layout-request.v1.schema.json",
    "data/layout-result.v1.schema.json",
    "data/layout-repair-intent.v1.schema.json",
)


def verify_tree(root, label):
    operator_guide = root / "docs" / "drawio-agent-extension-corporate-test-commands.md"
    if not operator_guide.is_file():
        fail(f"Missing {label} corporate operator guide: docs/drawio-agent-extension-corporate-test-commands.md")
    guide_text = operator_guide.read_text(encoding="utf-8")
    for marker in ("/drawio:review", "/drawio:trace", "/drawio:improve", "drawio-skill-agent-extension.zip.sha256"):
        if marker not in guide_text:
            fail(f"Missing {label} corporate operator guide marker: {marker}")
    if re.search(r"(?m)^SHA-256:\s*`[0-9a-f]{64}`", guide_text):
        fail(f"Self-referential ZIP checksum in {label} corporate operator guide")
    for relative in LAYOUT_RELEASE_FILES:
        if not (root / relative).is_file():
            fail(f"inventory mismatch: {relative}")
    for relative in (
        "scripts/diagram_host.py",
        "scripts/diagram_orchestrator.py",
        "scripts/agent_runtime.py",
        "scripts/command_ux.py",
        "scripts/lifecycle_contracts.py",
        "scripts/lifecycle_host_v2.py",
        "scripts/source_bundle_v2.py",
        "scripts/diagram_model_v2.py",
        "scripts/run_lock_v2.py",
        "scripts/evidence_v2.py",
        "scripts/implementation_snapshot_v2.py",
        "scripts/renderer_adapters.py",
        "data/reviewer-audit-input.v1.schema.json",
        "data/supervisor-decision.v1.schema.json",
        "data/semantic-plan.v1.schema.json",
        "data/checkpoint.v2.schema.json",
        "data/decision.v2.schema.json",
        "data/diagramspec.v2.schema.json",
        "data/implementation-snapshot.v2.schema.json",
        "data/publication-transaction.v2.schema.json",
        "data/semantic-analysis.v2.schema.json",
        "data/semantic-plan.v2.schema.json",
        "data/semantic-approval.v2.schema.json",
        "data/semantic-delta.v2.schema.json",
        "data/reviewer-analysis.v2.schema.json",
        "data/reviewer-input.v2.schema.json",
        "data/reviewer-verdict.v2.schema.json",
        "data/run-event.v2.schema.json",
        "data/source-bundle.v2.schema.json",
        "data/workflow.v2.schema.json",
        "data/run-state.v2.schema.json",
        "data/validation-receipt.v2.schema.json",
    ):
        if not (root / relative).is_file():
            fail(f"Missing {label} command host file: {relative}")
    for command_file in COMMAND_FILES:
        command_path = root / command_file
        if not command_path.is_file():
            fail(f"Missing {label} command host file: {command_file}")
        command_text = command_path.read_text(encoding="utf-8")
        if command_text.count("{{args}}") != 1:
            fail(f"{label} {command_file} must contain exactly one {{{{args}}}} placeholder")
        if "DRAWIO_COMMAND_ARGS={{args}}" not in command_text:
            fail(f"{label} {command_file} does not use the safe DRAWIO_COMMAND_ARGS bridge")
    command_ux = (root / "scripts" / "command_ux.py").read_text(encoding="utf-8")
    for marker in (
        "shlex.split", "HOST_OWNED_OPTIONS", "DRAWIO_COMMAND_ARGS",
        "DEFAULT_IMPROVE_REQUEST", "latest_review_handoff",
    ):
        if marker not in command_ux:
            fail(f"Missing {label} command argument bridge marker: {marker}")
    if "eval(" in command_ux or "shell=True" in command_ux:
        fail(f"Unsafe {label} command argument bridge implementation")
    review_host = (root / "scripts" / "diagram_host.py").read_text(encoding="utf-8")
    if '"improve": "/drawio:improve"' not in review_host:
        fail(f"Missing {label} zero-argument review-to-improve handoff")
    for marker in ('write_review_workflow', '"workflow.json"'):
        if marker not in review_host:
            fail(f"Missing {label} traceable review workflow marker: {marker}")
    orchestrator = (root / "scripts" / "diagram_orchestrator.py").read_text(encoding="utf-8")
    for marker in (
        'workflow["supervisor_declared_roles"]',
        'workflow["host_mandatory_roles"]',
        'workflow["required_roles"] = sorted(host_mandatory_roles)',
    ):
        if marker not in orchestrator:
            fail(f"Missing {label} host-owned role policy marker: {marker}")
    if "Supervisor decision must retain the supervisor role" in orchestrator:
        fail(f"Obsolete {label} Supervisor self-membership rejection remains active")
    if 'value.get("run_id") == reference' not in orchestrator:
        fail(f"Missing {label} persisted run-id trace resolution")
    agent_runtime = (root / "scripts" / "agent_runtime.py").read_text(encoding="utf-8")
    for marker in (
        '"--allowed-mcp-server-names", ""',
        '"allowed_mcp_servers": list(ROLE_ALLOWED_MCP_SERVERS)',
        '"--allowed-mcp-server-names", "--exclude-tools"',
    ):
        if marker not in agent_runtime:
            fail(f"Missing {label} empty MCP discovery marker: {marker}")
    for marker in (
        'return f"reviewer-analysis.v{version}.schema.json"',
        "def finalize_role_output",
        '"source": "validated_role_input"',
        "def correction_contract",
        '"contract-correction-1"',
    ):
        if marker not in agent_runtime:
            fail(f"Missing {label} host-bound Reviewer marker: {marker}")
    for relative in (
        "data/reviewer-analysis.v1.schema.json",
        "data/reviewer-analysis.v2.schema.json",
        "data/reviewer-input.v2.schema.json",
        "data/reviewer-verdict.v2.schema.json",
    ):
        if not (root / relative).is_file():
            fail(f"Missing {label} Reviewer contract: {relative}")
    manifest = load_json(root / "gemini-extension.json")
    if manifest.get("name") != "publish-drawio-skill":
        fail(f"Unexpected {label} manifest name: {manifest.get('name')!r}")
    if manifest.get("version") != expected_version:
        fail(f"Expected {label} version {expected_version}, found {manifest.get('version')!r}")
    if manifest.get("commands") != "commands":
        fail(f"Expected {label} commands directory, found {manifest.get('commands')!r}")
    generated = root / "gigacode-extension.json"
    if generated.exists():
        native = load_json(generated)
        for key in ("name", "version", "contextFileName"):
            if native.get(key) != manifest.get(key):
                fail(f"Active GigaCode manifest mismatch for {key}: {native.get(key)!r} != {manifest.get(key)!r}")
    policy = load_json(root / "data/model-routing.default.json")
    actual_models = {
        role: config.get("requested_model") for role, config in policy.get("roles", {}).items()
    }
    if actual_models != expected_models:
        fail(f"Unexpected {label} model routing: {actual_models!r}")
    for role, config in policy["roles"].items():
        if config.get("fallback_order") != ["isolated_cli", "native_per_agent", "inherited_current"]:
            fail(f"Unexpected {label} fallback order for {role}: {config.get('fallback_order')!r}")
    expected_supervisor_fallbacks = [{
        "model": "vllm/DeepSeek-V4-Flash-262k",
        "provider": "vllm",
        "on_failure": ["turn_limit"],
        "max_attempts": 1,
    }]
    expected_repair_fallbacks = [{
        "model": "vllm/Qwen3.6-35B-262k",
        "provider": "vllm",
        "on_failure": [
            "timeout", "turn_limit", "model_unavailable", "empty_response",
        ],
        "max_attempts": 1,
    }]
    if policy["roles"]["supervisor"].get("runtime_fallbacks") != expected_supervisor_fallbacks:
        fail(f"Unexpected {label} supervisor runtime fallback policy")
    if policy["roles"]["repair"].get("runtime_fallbacks") != expected_repair_fallbacks:
        fail(f"Unexpected {label} repair runtime fallback policy")
    for role in ("reviewer", "semantic_analyst"):
        if policy["roles"][role].get("runtime_fallbacks"):
            fail(f"Unexpected {label} runtime fallback for {role}")
    if policy["roles"]["reviewer"].get("provider") != "vllm":
        fail(f"Unexpected {label} reviewer provider")
    for role, filename in agent_files.items():
        values = frontmatter(root / "agents" / filename)
        if values.get("name") != f"diagram-{role.replace('_', '-')}":
            fail(f"Unexpected {label} agent name in {filename}: {values.get('name')!r}")
        if values.get("model") != expected_models[role]:
            fail(f"{label} {filename} model {values.get('model')!r} does not match routing policy")
        if not re.fullmatch(r"[1-9][0-9]*", values.get("maxTurns", "")):
            fail(f"{label} {filename} must declare positive maxTurns")
        for forbidden in ("max_turns", "kind", "temperature"):
            if forbidden in values:
                fail(f"Unsupported {label} frontmatter field {forbidden} in {filename}")
        if values.get("approvalMode") != "default":
            fail(f"{label} {filename} must use approvalMode: default")
    return manifest


active_manifest = verify_tree(active, "active")
if source:
    verify_tree(source, "source")


def manifest_entries(root):
    manifest_path = root / "MANIFEST.sha256"
    try:
        lines = manifest_path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        fail(f"Missing package manifest {manifest_path}: {exc}")
    entries = {}
    for number, line in enumerate(lines, 1):
        try:
            digest, relative = line.split("  ", 1)
        except ValueError:
            fail(f"Malformed MANIFEST.sha256 line {number}")
        path = PurePosixPath(relative)
        if (
            not re.fullmatch(r"[0-9a-f]{64}", digest)
            or path.is_absolute()
            or ".." in path.parts
            or "\\" in relative
            or re.match(r"^[A-Za-z]:", relative)
        ):
            fail(f"Unsafe MANIFEST.sha256 line {number}")
        if relative in entries:
            fail(f"Duplicate MANIFEST.sha256 entry: {relative}")
        entries[relative] = digest
    return entries


def payload_inventory(root):
    files = set()
    for current_dir, directories, filenames in os.walk(root, followlinks=False):
        current_path = Path(current_dir)
        for directory in directories:
            candidate = current_path / directory
            if candidate.is_symlink():
                fail(f"Symlinked directory in active package: {candidate.relative_to(root).as_posix()}")
        for filename in filenames:
            candidate = current_path / filename
            relative = candidate.relative_to(root).as_posix()
            if candidate.is_symlink():
                fail(f"Symlinked file in active package: {relative}")
            if filename == ".DS_Store" or relative in {
                "MANIFEST.sha256",
                "gigacode-extension.json",
                ".gigacode-extension-install.json",
            }:
                continue
            files.add(relative)
    return files


reference = source or active
entries = manifest_entries(reference)
if source:
    active_entries = manifest_entries(active)
    if active_entries != entries:
        mismatched = sorted(
            relative
            for relative in set(active_entries) | set(entries)
            if active_entries.get(relative) != entries.get(relative)
        )
        layout_mismatch = next(
            (relative for relative in mismatched if relative in LAYOUT_RELEASE_FILES),
            None,
        )
        if layout_mismatch is not None:
            fail(
                f"inventory mismatch: {layout_mismatch} "
                "(active/source manifest mismatch)"
            )
        fail("Active/source mismatch: MANIFEST.sha256")
for root, label in ((reference, "source" if source else "active"), (active, "active")):
    actual = payload_inventory(root)
    expected = set(entries)
    missing = sorted(expected - actual)
    extra = sorted(actual - expected)
    if missing or extra:
        fail(f"{label.capitalize()} inventory mismatch: missing={missing}, extra={extra}")
    for relative, digest in entries.items():
        target = root.joinpath(*PurePosixPath(relative).parts)
        actual_digest = hashlib.sha256(target.read_bytes()).hexdigest()
        if actual_digest != digest:
            if relative in LAYOUT_RELEASE_FILES:
                fail(
                    f"inventory mismatch: {relative} "
                    f"(manifest checksum mismatch in {label})"
                )
            fail(f"Manifest checksum mismatch in {label}: {relative}")

install_metadata = active / ".gigacode-extension-install.json"
if install_metadata.exists():
    metadata = load_json(install_metadata)
    if metadata.get("type") != "local" or metadata.get("originSource") != "Gemini":
        fail(f"Unexpected GigaCode install metadata: {metadata!r}")
    if metadata.get("source") != str(current):
        fail(f"Active extension source mismatch: {metadata.get('source')!r} != {str(current)!r}")

PY
read -r manifest_name manifest_version < <(
  "$PYTHON_BIN" - "$installed/gemini-extension.json" <<'PY'
import json, sys
data = json.load(open(sys.argv[1], encoding="utf-8"))
print(data.get("name", ""), data.get("version", ""))
PY
)

if [[ -e "$GIGACODE_SKILLS_DIR/drawio-skill" ]]; then
  die "Legacy skill is still active at $GIGACODE_SKILLS_DIR/drawio-skill; it would compete with the extension"
fi

list_output="$($GIGACODE_BIN extensions list 2>&1)" || die "GigaCode extensions list failed: $list_output"
grep -Fq "$EXTENSION_NAME" <<<"$list_output" || die "$EXTENSION_NAME is absent from GigaCode extensions list"

if extensions_supports_validate; then
  log "Running native GigaCode extension validation"
  "$GIGACODE_BIN" extensions validate "$installed"
else
  log "Native 'extensions validate' is unavailable; package integrity and registration checks remain active"
fi

if (( ! skip_self_check )); then
  [[ -f "$installed/scripts/self_check.py" ]] || die "Missing scripts/self_check.py"
  log "Running extension self-check"
  "$PYTHON_BIN" "$installed/scripts/self_check.py"
else
  log "Self-check skipped by request"
fi

log "Verified $EXTENSION_NAME $manifest_version"
log "Restart GigaCode, run /agents manage, and confirm the four diagram-* extension agents."
