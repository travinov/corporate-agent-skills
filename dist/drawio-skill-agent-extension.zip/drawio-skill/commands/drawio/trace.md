---
description: Verify and show the complete local role, model, tool, validation, and decision chain of a draw.io run
---

The deterministic trace verifier has already read the run. Do not call tools, agents,
shell, directory search, or file-reading operations. Present every role and effective
model plus any broken event or artifact binding. Never call an incomplete or tampered
trace verified.
For a new run, present `control_plane_v2` diagnostics for immutable snapshots,
source/decision/checkpoint bindings, receipt, implementation snapshot, and
publication transaction. For legacy v1 evidence, state that trace is read-only
and mutable resume is refused. Trace itself never performs recovery or writes.
`failed_verified` means failure evidence is intact, not that the diagram workflow
succeeded; present its failed role, capture paths, isolation proof, and diagnostic.
`verified_best_effort` means the evidence chain and delivered artifact are valid,
but strict validation still has explicitly classified layout/readability findings.
Treat a nonterminal Supervisor or Repair `role_failed` followed by an approved fallback
`role_finished` as recovered evidence, not as a hidden failure; report
`model_diversity_degraded` explicitly.
Also distinguish `working_artifact`, `publishable_candidate`, and final/published
artifacts, and show `internal_feedback_created`, `auto_retry_scheduled`, and
`patch_bound` evidence when present.

Normal use: `/drawio:trace` selects the most recently updated workflow.
Advanced form: `--run "run-id-or-directory"`.

```json
!{PYTHON=python3; if [ -n "$PYTHON_BIN" ]; then PYTHON="$PYTHON_BIN"; fi; GC_HOME="$HOME/.gigacode"; if [ -n "$GIGACODE_HOME" ]; then GC_HOME="$GIGACODE_HOME"; fi; EXTENSIONS="$GC_HOME/extensions"; if [ -n "$GIGACODE_EXTENSIONS_DIR" ]; then EXTENSIONS="$GIGACODE_EXTENSIONS_DIR"; fi; DRAWIO_COMMAND_ARGS={{args}} "$PYTHON" "$EXTENSIONS/publish-drawio-skill/scripts/diagram_orchestrator.py" trace --workspace "$PWD" 2>&1}
```
