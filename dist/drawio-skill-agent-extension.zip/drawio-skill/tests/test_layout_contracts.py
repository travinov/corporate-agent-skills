import copy
import json
import sys
import unittest
from pathlib import Path

import jsonschema


ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))

import layout_contracts
import lifecycle_contracts


SHA = "a" * 64


def valid_intake():
    return {
        "schema_version": 1, "intake_id": "intake-1", "mode": "create",
        "request_sha256": SHA, "status": "complete",
        "classification": {
            "selected": "flowchart", "source": "explicit",
            "confidence": 1, "candidates": ["flowchart"],
        },
        "questions": [], "answers": [], "assumptions": [], "completeness": 1,
    }


def valid_intake_analysis():
    return {
        "schema_version": 1, "role": "semantic_analyst", "status": "ok",
        "result": {
            "diagram_type": "flowchart", "confidence": 1,
            "alternatives": [], "sufficient": True,
            "blocking_questions": [], "assumptions": [],
        },
    }


def valid_layout_request(mode="create"):
    return {
        "schema_version": 1, "request_id": "request-1", "run_id": "run-1",
        "semantic_plan_sha256": SHA, "diagram_type": "flowchart", "direction": "LR",
        "mode": mode, "backend": "builtin", "strategy": "layered",
        "quality_profile_version": 1,
        "pages": [{
            "page_id": "page-1", "name": "Page 1",
            "nodes": [
                {"node_id": "node-1", "x": 0, "y": 0, "width": 100, "height": 60, "locked": True},
                {"node_id": "node-2", "x": 200, "y": 0, "width": 100, "height": 60, "locked": False},
            ],
            "edges": [{
                "edge_id": "edge-1", "source": "node-1", "target": "node-2", "edge_class": "main",
                "source_port": "east", "target_port": "west",
                "locked": False,
                "waypoints": [{"x": 100, "y": 30}, {"x": 200, "y": 30}],
            }],
        }],
        "scope": {
            "page_ids": ["page-1"],
            "node_refs": [{"page_id": "page-1", "cell_id": "node-1"}, {"page_id": "page-1", "cell_id": "node-2"}],
            "edge_refs": [{"page_id": "page-1", "cell_id": "edge-1"}],
            "movable_node_refs": [{"page_id": "page-1", "cell_id": "node-2"}],
            "reroutable_edge_refs": [{"page_id": "page-1", "cell_id": "edge-1"}],
        },
        "constraints": {"grid_size": 10, "node_separation": 40, "layer_separation": 80},
    }


def valid_layout_result():
    pages = copy.deepcopy(valid_layout_request()["pages"])
    for page in pages:
        for edge in page["edges"]:
            edge.pop("locked")
            edge["source_pin"] = 0.5
            edge["target_pin"] = 0.5
            edge["label_bounds"] = {"x": 120, "y": 20, "width": 40, "height": 20}
    return {
        "schema_version": 1, "result_id": "result-1", "request_sha256": SHA, "backend": "builtin",
        "pages": pages,
        "metrics": {
            "crossings": 0, "overlaps": 0, "route_length": 100,
            "bend_count": 0, "shared_route_length": 0, "label_collisions": 0,
        },
    }


def valid_repair_intent():
    return {
        "schema_version": 1, "role": "repair", "status": "ok", "run_id": "run-1",
        "baseline_sha256": SHA,
        "result": {"action": "reroute_edges", "page_id": "page-1", "node_ids": [], "edge_ids": ["edge-1"], "reason": "avoid crossing"},
    }


class LayoutContractTests(unittest.TestCase):
    def test_layout_request_strategy_options_are_strict_and_finite(self):
        value = valid_layout_request()
        value["strategy_options"] = {
            "spacing": 1.35,
            "port_separation": 1.4,
            "shared_penalty": 1.6,
        }
        self.assertEqual(layout_contracts.validate_layout_request(value), [])
        value["strategy_options"]["unknown"] = 1
        self.assertTrue(layout_contracts.validate_layout_request(value))
        value["strategy_options"].pop("unknown")
        value["strategy_options"]["spacing"] = float("inf")
        self.assertTrue(
            any(
                diagnostic["code"] == "layout.number.non_finite"
                for diagnostic in layout_contracts.validate_layout_request(value)
            )
        )

    def test_schemas_compile_and_accept_positive_documents(self):
        fixtures = {
            "diagram-intake": valid_intake(),
            "diagram-intake-analysis": valid_intake_analysis(),
            "layout-request": valid_layout_request(),
            "layout-result": valid_layout_result(),
            "layout-repair-intent": valid_repair_intent(),
        }
        for kind, document in fixtures.items():
            with self.subTest(kind=kind):
                schema = lifecycle_contracts.load_schema(kind, 1)
                jsonschema.Draft202012Validator.check_schema(schema)
                self.assertEqual(lifecycle_contracts.validate_contract(document, kind, 1), [])

    def test_all_contract_owned_objects_reject_unknown_fields(self):
        value = valid_layout_request()
        value["unknown"] = True
        self.assertTrue(layout_contracts.validate_layout_request(value))

    def test_layout_request_create_can_omit_model_generated_route(self):
        value = valid_layout_request()
        value["pages"][0]["edges"][0].pop("waypoints")
        value["pages"][0]["edges"][0]["locked"] = False
        self.assertEqual(layout_contracts.validate_layout_request(value), [])

    def test_layout_request_locked_route_requires_waypoints(self):
        value = valid_layout_request()
        value["pages"][0]["edges"][0].pop("waypoints")
        value["pages"][0]["edges"][0]["locked"] = True
        diagnostics = layout_contracts.validate_layout_request(value)
        self.assertTrue(diagnostics)

    def test_layout_request_accepts_explicit_baseline_hashes_and_edge_lock(self):
        value = valid_layout_request(mode="local_reflow")
        value["pages"][0]["nodes"][0]["element_sha256"] = SHA
        value["pages"][0]["edges"][0]["element_sha256"] = SHA
        value["pages"][0]["edges"][0]["locked"] = True
        self.assertEqual(layout_contracts.validate_layout_request(value), [])

    def test_layout_request_accepts_explicit_edge_label_size(self):
        value = valid_layout_request()
        value["pages"][0]["edges"][0]["locked"] = False
        value["pages"][0]["edges"][0]["label_size"] = {"width": 40, "height": 20}
        self.assertEqual(layout_contracts.validate_layout_request(value), [])

    def test_layout_request_accepts_same_page_parent_and_rejects_invalid_parent_graph(self):
        value = valid_layout_request()
        value["pages"][0]["nodes"][1]["parent_id"] = "node-1"
        self.assertEqual(layout_contracts.validate_layout_request(value), [])
        value["pages"][0]["nodes"][0]["parent_id"] = "node-2"
        codes = {item["code"] for item in layout_contracts.validate_layout_request(value)}
        self.assertIn("layout.parent.cycle", codes)

    def test_layout_request_rejects_unknown_quality_profile_version(self):
        value = valid_layout_request()
        value["quality_profile_version"] = 3
        self.assertTrue(layout_contracts.validate_layout_request(value))

    def test_layout_result_rejects_diagonal_route(self):
        value = valid_layout_result()
        value["pages"][0]["edges"][0]["waypoints"] = [
            {"x": 100, "y": 100},
            {"x": 140, "y": 130},
        ]
        diagnostics = layout_contracts.validate_layout_result(value)
        self.assertIn("waypoints", json.dumps(diagnostics))

    def test_layout_request_rejects_unlocked_out_of_scope_node(self):
        value = valid_layout_request(mode="local_reflow")
        value["pages"][0]["nodes"][1]["locked"] = False
        value["scope"]["movable_node_refs"] = []
        diagnostics = layout_contracts.validate_layout_request(value)
        self.assertTrue(diagnostics)

    def test_layout_request_rejects_movable_node_outside_declared_scope(self):
        value = valid_layout_request(mode="local_reflow")
        value["scope"]["movable_node_refs"] = [{"page_id": "page-1", "cell_id": "outside"}]
        codes = {item["code"] for item in layout_contracts.validate_layout_request(value)}
        self.assertIn("layout.scope.movable_node_outside", codes)

    def test_layout_request_rejects_overlapping_locked_and_movable_sets(self):
        value = valid_layout_request(mode="local_reflow")
        value["scope"]["movable_node_refs"] = [
            {"page_id": "page-1", "cell_id": "node-1"},
            {"page_id": "page-1", "cell_id": "node-2"},
        ]
        codes = {item["code"] for item in layout_contracts.validate_layout_request(value)}
        self.assertIn("layout.scope.locked_movable_overlap", codes)

    def test_layout_result_binds_to_immutable_request_digest(self):
        value = valid_layout_result()
        diagnostics = layout_contracts.validate_layout_result(value, expected_request_sha256="b" * 64)
        self.assertEqual(diagnostics[0]["code"], "layout.result.request_sha256_mismatch")

    def test_layout_result_requires_normalized_pins_and_label_collision_metric(self):
        value = valid_layout_result()
        value["pages"][0]["edges"][0]["source_pin"] = 0.09
        self.assertTrue(layout_contracts.validate_layout_result(value))
        value = valid_layout_result()
        value["metrics"].pop("label_collisions")
        self.assertTrue(layout_contracts.validate_layout_result(value))

    def test_layout_result_accepts_optional_explicit_route_group(self):
        value = valid_layout_result()
        value["pages"][0]["edges"][0]["route_group"] = "approved-bus-1"
        self.assertEqual(layout_contracts.validate_layout_result(value), [])

    def test_layout_result_rejects_empty_route_group(self):
        value = valid_layout_result()
        value["pages"][0]["edges"][0]["route_group"] = ""
        self.assertTrue(layout_contracts.validate_layout_result(value))

    def test_layout_result_rejects_diagonal_or_unknown_channel_reservation(self):
        value = valid_layout_result()
        value["pages"][0]["channel_reservations"] = [{
            "edge_id": "missing",
            "start": {"x": 0, "y": 0},
            "end": {"x": 10, "y": 10},
        }]
        codes = {item["code"] for item in layout_contracts.validate_layout_result(value)}
        self.assertIn("layout.reservation.diagonal_segment", codes)
        self.assertIn("layout.reservation.edge_missing", codes)

    def test_layout_result_rejects_endpoint_on_wrong_declared_side(self):
        value = valid_layout_result()
        value["pages"][0]["edges"][0]["source_port"] = "north"
        codes = {item["code"] for item in layout_contracts.validate_layout_result(value)}
        self.assertIn("layout.route.source_endpoint_side", codes)

    def test_layout_result_rejects_endpoint_inside_source_instead_of_on_boundary(self):
        value = valid_layout_result()
        value["pages"][0]["edges"][0]["waypoints"][0] = {"x": 90, "y": 30}
        codes = {item["code"] for item in layout_contracts.validate_layout_result(value)}
        self.assertIn("layout.route.source_endpoint_side", codes)

    def test_layout_request_rejects_non_finite_contract_numbers(self):
        locations = (
            ("pages", 0, "nodes", 0, "x"),
            ("pages", 0, "nodes", 0, "width"),
            ("constraints", "grid_size"),
            ("constraints", "node_separation"),
            ("constraints", "layer_separation"),
        )
        for number in (float("nan"), float("inf"), float("-inf")):
            for location in locations:
                with self.subTest(number=number, location=location):
                    value = valid_layout_request()
                    target = value
                    for part in location[:-1]:
                        target = target[part]
                    target[location[-1]] = number
                    codes = {item["code"] for item in layout_contracts.validate_layout_request(value)}
                    self.assertIn("layout.number.non_finite", codes)

    def test_layout_result_rejects_non_finite_contract_numbers(self):
        locations = (
            ("pages", 0, "nodes", 0, "x"),
            ("pages", 0, "nodes", 0, "height"),
            ("metrics", "crossings"),
            ("metrics", "route_length"),
        )
        for number in (float("nan"), float("inf"), float("-inf")):
            for location in locations:
                with self.subTest(number=number, location=location):
                    value = valid_layout_result()
                    target = value
                    for part in location[:-1]:
                        target = target[part]
                    target[location[-1]] = number
                    codes = {item["code"] for item in layout_contracts.validate_layout_result(value)}
                    self.assertIn("layout.number.non_finite", codes)

    def test_diagram_intake_rejects_non_finite_completeness(self):
        for number in (float("nan"), float("inf"), float("-inf")):
            with self.subTest(number=number):
                value = valid_intake()
                value["completeness"] = number
                codes = {item["code"] for item in layout_contracts.validate_diagram_intake(value)}
                self.assertIn("layout.number.non_finite", codes)

    def test_diagram_intake_analysis_rejects_non_finite_nested_completeness(self):
        for number in (float("nan"), float("inf"), float("-inf")):
            with self.subTest(number=number):
                value = valid_intake_analysis()
                value["result"]["confidence"] = number
                codes = {item["code"] for item in layout_contracts.validate_diagram_intake_analysis(value)}
                self.assertIn("layout.number.non_finite", codes)

    def test_intake_analysis_rejects_host_owned_state(self):
        value = valid_intake_analysis()
        value["result"]["intake_id"] = "model-owned"
        self.assertTrue(layout_contracts.validate_diagram_intake_analysis(value))

    def test_host_intake_rejects_analysis_only_shape(self):
        value = valid_intake()
        value["result"] = valid_intake_analysis()["result"]
        self.assertTrue(layout_contracts.validate_diagram_intake(value))

    def test_public_validator_accepts_mixed_mapping_keys_without_raising(self):
        value = valid_layout_request()
        value[1] = float("nan")
        diagnostics = layout_contracts.validate_layout_request(value)
        self.assertIn("layout.number.non_finite", {item["code"] for item in diagnostics})

    def test_require_helpers_raise_contract_error_for_diagnostics(self):
        invalid = copy.deepcopy(valid_layout_result())
        invalid["pages"][0]["edges"][0]["waypoints"][1]["y"] = 10
        with self.assertRaises(lifecycle_contracts.ContractError):
            layout_contracts.require_layout_result(invalid)


if __name__ == "__main__":
    unittest.main()
